﻿using System;

class Interest
{
    static void Main()
    {
        // Kullanıcıdan başlangıç miktarını al
        Console.Write("Başlangıç miktarını girin (örnek: 1000): ");
        decimal principal = Convert.ToDecimal(Console.ReadLine());

        // Kullanıcıdan faiz oranını al
        Console.Write("Faiz oranını yüzde olarak girin (örnek: 5): ");
        double rate = Convert.ToDouble(Console.ReadLine()) / 100;

        // Başlıkları göster
        Console.WriteLine("\nYear   Amount on deposit");

        // On yıl boyunca her yılın bakiyesini hesapla  
        for (int year = 1; year <= 10; ++year)
        {
            // Belirtilen yıl için yeni miktarı hesapla 
            decimal amount = principal * ((decimal)Math.Pow(1.0 + rate, year));

            // Yıl ve miktarı göster         
            Console.WriteLine($"{year,4}{amount,20:C}");
            Console.ReadLine();
        }
    }
}
